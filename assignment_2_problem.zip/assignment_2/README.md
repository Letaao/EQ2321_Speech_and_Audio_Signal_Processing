# Install

This has been tested on `Ubuntu 20.04.3 LTS` with `Python 3.8.10`.
Feel free to use [conda](https://www.anaconda.com/products/individual) to create a virtual environment.


## Virtual environment
```bash
$ virtualenv -p python3 pyenv
$ source pyenv/bin/activate
(pyenv) $ python
Python 3.8.10 (default, Nov 26 2021, 20:14:08) 
[GCC 9.3.0] on linux
Type "help", "copyright", "credits" or "license" for more information.
>>> exit
```

## Dependencies
Make sure your virtual environment is activated (for me `source pyenv/bin/activate`)
```
(pyenv) $ pip install jupyter sounddevice numpy matplotlib scipy
(pyenv) $ ipython kernel install --user --name "speechproc"
(pyenv) $ jupyter notebook
```

Make sure to select the kernel called `speechproc` in the kernel list after opening the assignment notebook.


The tutorials shouldn't be too dependent upon exact library versions.
In case they are needed though:
```bash
$ cat requirements.txt
argon2-cffi==21.3.0
argon2-cffi-bindings==21.2.0
attrs==21.4.0
backcall==0.2.0
bleach==4.1.0
cffi==1.15.0
cycler==0.11.0
debugpy==1.5.1
decorator==5.1.0
defusedxml==0.7.1
entrypoints==0.3
fonttools==4.28.5
importlib-resources==5.4.0
ipykernel==6.6.1
ipython==7.30.1
ipython-genutils==0.2.0
ipywidgets==7.6.5
jedi==0.18.1
Jinja2==3.0.3
jsonschema==4.3.3
jupyter==1.0.0
jupyter-client==7.1.0
jupyter-console==6.4.0
jupyter-core==4.9.1
jupyterlab-pygments==0.1.2
jupyterlab-widgets==1.0.2
kiwisolver==1.3.2
MarkupSafe==2.0.1
matplotlib==3.5.1
matplotlib-inline==0.1.3
mistune==0.8.4
nbclient==0.5.9
nbconvert==6.4.0
nbformat==5.1.3
nest-asyncio==1.5.4
notebook==6.4.6
numpy==1.22.0
packaging==21.3
pandocfilters==1.5.0
parso==0.8.3
pexpect==4.8.0
pickleshare==0.7.5
Pillow==9.0.0
prometheus-client==0.12.0
prompt-toolkit==3.0.24
ptyprocess==0.7.0
pycparser==2.21
Pygments==2.11.1
pyparsing==3.0.6
pyrsistent==0.18.0
python-dateutil==2.8.2
pyzmq==22.3.0
qtconsole==5.2.2
QtPy==2.0.0
scipy==1.7.3
Send2Trash==1.8.0
six==1.16.0
sounddevice==0.4.4
terminado==0.12.1
testpath==0.5.0
tornado==6.1
traitlets==5.1.1
wcwidth==0.2.5
webencodings==0.5.1
widgetsnbextension==3.5.2
zipp==3.7.0
```
